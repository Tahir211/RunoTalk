Bot Altyapı Projesine Hoşgeldin!
=================
 Bu Dosya Tamamen `Emirhan Saraç'a Aittir`. Bot Altyapısını Sizlerin Kullanması İçin Verdik Gerekli Modüller Yüklüdür..!

[Resmi Discord Sunucumuz](https://discord.gg/NG8qEX3)

[Resmi Youtube Kanalımız](https://www.youtube.com/channel/UCVRhrcoG6FOvHGKehYtvKHg?view_as=subscriber)

[Resmi İnstagram Hesabımız](https://www.instagram.com/emirhan_sarac54/)


-------------------

`İyi Kodlamalar ay iyi düzeltmeler`

